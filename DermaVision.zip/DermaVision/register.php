<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="author" content="Muhamad Nauval Azhar">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="This is a login page template based on Bootstrap 5">
  <link rel="stylesheet" href="css/style.css">
  <title>Bootstrap 5 Login Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>

<body>
	<div class="text-center my-3">
		<h1 id="main-heading">DermaVision</h1>
	</div>
  <section class="vh-100 gradient-custom">
    <div class="container  h-80">
      <div class="row justify-content-center align-items-center h-100">
        <div class="col-12 col-lg-9 col-xl-9">
          <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
            <div class="card-body p-4 p-md-3">
              <h3 class="mb-4 pb-2 pb-md-0 mb-md-4">Signup</h3>
              <form>

                <div class="row">
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="firstName">User Name</label>
                      <input type="text" id="firstName" class="form-control form-control-md" placeholder="User Name">
                    </div>

                  </div>
                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="emailAddress">Email</label>
                      <input type="email" id="emailAddress" class="form-control form-control-md" placeholder="Email">

                    </div>

                  </div>
                </div>

                <div class="row">

                  <div class="col-md-6 mb-4">

                    <div class="form-outline">
                      <label class="form-label" for="phoneNumber">Phone Number</label>
                      <input type="tel" id="phoneNumber" class="form-control form-control-md" placeholder="Ph No.">

                    </div>


                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6 mb-4 pb-2">

                    <div class="form-outline">
                      <label class="form-label" for="passWord">Password</label>
                      <input type="password" id="passWord" class="form-control form-control-md" placeholder="Enter Password">

                    </div>

                  </div>
                  <div class="col-md-6 mb-4 pb-2">

                    <div class="form-outline">
                      <label class="form-label" for="passWord">Confirm Password</label>
                      <input type="password" id="passWord" class="form-control form-control-md" placeholder="Enter Password">
                    </div>

                  </div>
                </div>

                <div class="alignment-of-buttons">
                  <div class="mt-4 pt-2">
                    <input class="btn btn-primary btn-lg" type="submit" value="SignUp" />


                    <a href="login.php">
                      <button type="button" class="btn btn-secondary btn-lg ms-auto">
                        Back </button></a>


                  </div>
                </div>



              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="js/login.js"></script>
</body>

</html>
