


<!DOCTYPE html>
<html>
<head>
    <html lang="en">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>DermaVision - Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">label
    <link rel="stylesheet" href="css/style2.css">
</head>

<body id="page-top">

    <?php include('sidenavbar.php'); ?>


    <div class="container-fluid ">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-900">Update Doctor</h1>
        <p class="mb-4">Update Doctor Details.</p>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-info">Update Details</h6>
            </div>
            <div class="card-body">
                <form>

           <div class="row">
             <div class="col-md-6 mb-4">

               <div class="form-outline">
                 <label class="form-label" for="Name">Name :</label>
                 <input type="text" id="Name" class="form-control form-control-md" placeholder="Name" />


               </div>

             </div>

           </div>

           <div class="row">

             <div class="col-md-12 mb-4 pb-2">

               <div class="form-outline">
                 <label class="form-label" for="description">Description :</label>
                 <input placeholder="Complaint Description" type="text" id="description" class="form-control form-control-md" />

               </div>

             </div>



</div>
           <div class="row">
             <div class="col-sm-3 mb-2 ">
               <div class="form-outline  w-100">
                <label for="complaint-reply" class="form-label">Reply :</label>
                 <input type="text" class="form-control form-control-md" id="complaint-reply" placeholder="Write your reply"/>

               </div>
           </div>



           </div>

              <div class="mt-4 pt-1">
             <input class="btn btn-info btn-md" type="submit" value="Update" />
            <a href='view-complaints.php' class='btn btn-danger btn-md text-white'>Back</a>
           </div>

         </form>
            </div>
        </div>


    </div>

    <!-- /.container-fluid -->


    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->




    <?php include('scrollup-button.php') ?> <!-- //shows scroll up button when the page is down -->
    <?php include('logout-model.php') ?> <!-- //asks user to logout in popup -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>
</html>
